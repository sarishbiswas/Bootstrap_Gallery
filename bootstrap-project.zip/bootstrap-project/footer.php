<!DOCTYPE html>
<html>
  <head>
    <title>Homepage</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style type="text/css">
    .anindita{
      padding-left: 30%;
    }
    .ani{
      padding-left: 35%;
    }
    .trayee{
      padding-left: 50%;
    }</style>
  </head>
  <body>

    <nav class="navbar navbar-inverse ">
        <div class="container anindita"><p class="navbar-brand">© 2020 Copyright:</p>
          <a class="navbar-brand" href="home.php">Sarish's-Gallery.com</a>
        </div>
    </nav>
    
  </body>
</html>